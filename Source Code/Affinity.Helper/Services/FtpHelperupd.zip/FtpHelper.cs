﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.IO;

namespace Affinity.Helper.Services
{
    /// <summary>
    /// Ftp Helper
    /// </summary>
    public class FtpHelper
    {
        /// <summary>
        /// Private FTPWebRequest method
        /// </summary>
        private FtpWebRequest _ftprequest { get; set; }
        /// <summary>
        /// The FTP User Name
        /// </summary>
        private string _UserName { get; set; }
        /// <summary>
        /// The FTP PassWord
        /// </summary>
        private string _PassWord { get; set; }
        /// <summary>
        /// The Server Host
        /// </summary>
        private string _SrvHost { get; set; }
        /// <summary>
        /// The Port Number
        /// </summary>
        private int _PortNo { get; set; }
        /// <summary>
        /// The folder Name
        /// </summary>
        /// <remarks>
        /// This a folder name inside the root folder define for the specific FTP Account.
        /// </remarks>
        private string _folderName { get; set; }
        /// <summary>
        /// Use Proxy true or false
        /// </summary>
        private Boolean _useProxy { get; set; }
        /// <summary>
        /// The Proxy URL
        /// </summary>
        private string _ProxyURL { get; set; }

        /// <summary>
        /// Initialization of FTP method
        /// </summary>
        /// <param name="SrvHost">The FTP Host</param>
        /// <param name="usrName">The username</param>
        /// <param name="PassStr">The PassWord</param>
        /// <param name="FtpPort">The Port number</param>
        /// <param name="FolderPath">Folder Path</param>
        /// <param name="UseProxy">True or False</param>
        /// <param name="ProxyURL">The Proxy Address</param>
        public FtpHelper(string SrvHost,string usrName,string PassStr,int FtpPort,string FolderPath,Boolean UseProxy, string ProxyURL)
        {
            _SrvHost = SrvHost;
            _UserName = usrName;
            _PassWord = PassStr;
            _PortNo = FtpPort;
            _folderName = FolderPath;
            _useProxy = UseProxy;
            _ProxyURL = ProxyURL;


        }

        /// <summary>
        /// List Of Files 
        /// </summary>
        /// <param name="FilterStr">String to Filter the Files Selection</param>
        /// <returns></returns>
        public string[] ListDirFiles(string FilterStr)
        {

            var FtpServerUrl = "ftp://" + _SrvHost + ":" + _PortNo.ToString();
            if (_folderName != "")
            {
                FtpServerUrl = FtpServerUrl + "/" + _folderName;
            }
            _ftprequest = (FtpWebRequest)WebRequest.Create(FtpServerUrl);
            _ftprequest.Credentials = new NetworkCredential(_UserName, _PassWord);

            if (_useProxy == true)
            {
                _ftprequest.Proxy = new WebProxy(_ProxyURL);

            }
            _ftprequest.UsePassive = false;
            _ftprequest.Method = WebRequestMethods.Ftp.ListDirectory;
            FtpWebResponse response = (FtpWebResponse)_ftprequest.GetResponse();
            Stream responseStream = response.GetResponseStream();
            StreamReader myreader = new StreamReader(responseStream);
            var myResult = myreader.ReadToEnd();
            string[] myfiles = myResult.Replace("\n","").Split('\r');
            myfiles = myfiles.Where(o => o.Contains(FilterStr)).ToArray();
            myreader.Close();
            response.Close();
            return myfiles;
            
        }


        /// <summary>
        /// Download a File to Stream
        /// </summary>
        /// <param name="FileName">The File Name to Download</param>
        /// <returns></returns>
        public StreamReader DownLoadToStream(string FileName)
        {
            var FtpServerUrl = "ftp://" + _SrvHost + ":" + _PortNo.ToString();
            if (_folderName != "")
            {
                FtpServerUrl = FtpServerUrl + "/" + _folderName;
            }

            //After any Folder , Add the File to URI
            FtpServerUrl = FtpServerUrl + "/" + FileName;

            _ftprequest.UsePassive = false;
            _ftprequest = (FtpWebRequest)WebRequest.Create(FtpServerUrl);
            _ftprequest.Method = WebRequestMethods.Ftp.DownloadFile;
            _ftprequest.Credentials = new NetworkCredential(_UserName, _PassWord);

            if (_useProxy == true)
            {
                _ftprequest.Proxy = new WebProxy(_ProxyURL);

            }


            FtpWebResponse response = (FtpWebResponse)_ftprequest.GetResponse();
            Stream responseStream = response.GetResponseStream();
            StreamReader myreader = new StreamReader(responseStream);
            return myreader;
          /*  using (var FileStream = File.Create("C:\\DownTest\\" + FileName))
            {
            //    myreader.BaseStream.Seek(0, SeekOrigin.Begin);
               myreader.BaseStream.CopyTo(FileStream);
                myreader.Close();
            }

            response.Close();
            */

        }



    }
}
